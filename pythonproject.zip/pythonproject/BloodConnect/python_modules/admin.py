from python_modules.user import User
from python_modules.donor import Donor
from python_modules.file_manager import FileManager
from python_modules.validation import ValidationError, validate_donor_data


class Admin(User):

    def __init__(
        self,
        admin_id: str,
        username: str,
        password_hash: str,
        full_name: str,
        email: str,
    ):
        super().__init__(
            user_id=admin_id,
            full_name=full_name,
            email=email,
            phone="N/A",
            password_hash=password_hash,
            city="HQ",
            area="Main Administration",
        )
        self.username = str(username).strip()

    # Topic 23: Polymorphism - Overriding display_profile()
    def display_profile(self) -> dict:
        profile = super().display_profile()
        profile["username"] = self.username
        profile["role"] = "System Administrator"
        profile["access_level"] = "Full Administrative Control"
        return profile

    def to_file_record(self) -> str:
        
        fields = [
            self.user_id,
            self.username,
            self.password_hash,
            self.full_name,
            self.email,
        ]
        return "|".join(fields) + "\n"

# Topic 19: Procedural & OOP Administration Service
class AdminService:

    @staticmethod
    def authenticate(username: str, plain_password: str):
        
        clean_username = username.strip().lower()
        admins = FileManager.read_admins()
        for admin in admins:
            if admin.username.lower() == clean_username:
                if admin.check_password(plain_password):
                    return admin
        return None

    @staticmethod
    def view_all_donors() -> list:
        """Returns all registered donors."""
        return FileManager.read_donors()

    @staticmethod
    def view_all_users() -> list:
        """Returns all registered normal users."""
        return FileManager.read_users()

    @staticmethod
    def view_all_requests() -> list:
        return FileManager.read_emergency_requests()

    @staticmethod
    def add_donor(form_data: dict) -> Donor:
       
        validated = validate_donor_data(form_data)
        donors = FileManager.read_donors()

        
        max_num = 100
        for d in donors:
            if d.user_id.startswith("DON") and d.user_id[3:].isdigit():
                max_num = max(max_num, int(d.user_id[3:]))
        new_id = f"DON{max_num + 1}"

        from python_modules.user import hash_password
        plain_pw = form_data.get("password", "donor123").strip() or "donor123"
        pw_hash = hash_password(plain_pw)

        donor = Donor(
            donor_id=new_id,
            full_name=validated["full_name"],
            email=validated["email"],
            phone=validated["phone"],
            password_hash=pw_hash,
            blood_group=validated["blood_group"],
            age=validated["age"],
            city=validated["city"],
            area=validated["area"],
            last_donation_date=validated["last_donation_date"],
            availability=validated["availability"],
        )
        FileManager.append_donor(donor)
        return donor

    @staticmethod
    def update_donor(donor_id: str, **kwargs) -> bool:
        """Updates specific fields of an existing donor."""
        return FileManager.update_donor(donor_id, **kwargs)

    @staticmethod
    def delete_donor(donor_id: str) -> bool:
        """Deletes donor by ID."""
        return FileManager.delete_donor(donor_id)

    @staticmethod
    def delete_user(user_id: str) -> bool:
        """Deletes normal user by ID."""
        return FileManager.delete_user(user_id)

    @staticmethod
    def update_emergency_status(request_id: str, new_status: str) -> bool:
        """Updates status of an emergency blood request."""
        return FileManager.update_request_status(request_id, new_status)

    @staticmethod
    def delete_emergency_request(request_id: str) -> bool:
        """Deletes an emergency blood request by ID."""
        return FileManager.delete_emergency_request(request_id)
