import re

VALID_BLOOD_GROUPS_SET = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}

NAME_REGEX = re.compile(r"^[A-Za-z\s.'-]{2,50}$")

PHONE_REGEX = re.compile(r"^\+?[1-9]{10}$")

EMAIL_REGEX = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")

PASSWORD_REGEX = re.compile(r"^[A-Za-z0-9@#$%^&+=!._-]{6,30}$")

SEARCH_REGEX = re.compile(r"[^A-Za-z0-9\s]")

DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")

class ValidationError(Exception):

    def __init__(self, message: str, field_name: str = ""):
        super().__init__(message)
        self.message = message
        self.field_name = field_name

    def __str__(self):
        if self.field_name:
            return f"Validation error on '{self.field_name}': {self.message}"
        return self.message

def validate_name(name: str, field_label: str = "Name") -> str:
    cleaned = str(name).strip()
    if len(cleaned) < 2:
        raise ValidationError(f"{field_label} must contain at least 2 characters.", field_label)
    if not NAME_REGEX.fullmatch(cleaned):
        raise ValidationError(
            f"{field_label} can only contain letters, spaces, hyphens, and periods.",
            field_label,
        )
    return cleaned


def validate_email(email: str) -> str:
    cleaned = str(email).strip().lower()
    if not cleaned:
        raise ValidationError("Email address is required.", "email")
    if not EMAIL_REGEX.fullmatch(cleaned):
        raise ValidationError("Please provide a valid email address (e.g. user@gmail.com).", "email")
    return cleaned


def validate_phone(phone: str) -> str:
    cleaned = str(phone).strip().replace(" ", "").replace("-", "")
    if not cleaned:
        raise ValidationError("Phone number is required.", "phone")
    if not PHONE_REGEX.fullmatch(cleaned):
        raise ValidationError("Phone number must contain 10 to 12 digits (e.g. 9876543210).", "phone")
    return cleaned


def validate_password(password: str) -> str:
    cleaned = str(password).strip()
    if len(cleaned) < 6:
        raise ValidationError("Password must contain at least 6 characters.", "password")
    if not PASSWORD_REGEX.fullmatch(cleaned):
        raise ValidationError(
            "Password must be between 6 and 30 characters and contain letters/numbers.",
            "password",
        )
    return cleaned


def validate_age(age_val) -> int:
    try:
        val = int(str(age_val).strip())
    except (ValueError, TypeError):
        raise ValidationError("Age must be a valid number.", "age")
    if val < 18 or val > 65:
        raise ValidationError(f"Donor age must be between 18 and 65 years (received {val}).", "age")
    return val


def validate_blood_group(group_val: str) -> str:
    cleaned = str(group_val).strip().upper()
    if cleaned not in VALID_BLOOD_GROUPS_SET:
        raise ValidationError(
            f"Invalid blood group '{cleaned}'. Must be one of: {', '.join(sorted(VALID_BLOOD_GROUPS_SET))}",
            "blood_group",
        )
    return cleaned


def validate_city(city: str) -> str:
    cleaned = str(city).strip()
    if not cleaned or len(cleaned) < 2:
        raise ValidationError("City must contain at least 2 characters.", "city")
    return cleaned.title()


def validate_area(area: str) -> str:
    cleaned = str(area).strip()
    if not cleaned or len(cleaned) < 2:
        raise ValidationError("Area / Locality must contain at least 2 characters.", "area")
    return cleaned.title()


def validate_date(date_str: str) -> str:
    cleaned = str(date_str).strip()
    if not cleaned or cleaned == "Not available":
        return "Not available"
    if not DATE_REGEX.fullmatch(cleaned):
        raise ValidationError("Date must follow YYYY-MM-DD format.", "date")
    return cleaned


def validate_user_registration(data: dict) -> dict:
    
    pw = validate_password(data.get("password", ""))
    confirm_pw = data.get("confirm_password", "").strip()
    if pw != confirm_pw:
        raise ValidationError("Passwords do not match.", "confirm_password")

    return {
        "full_name": validate_name(data.get("full_name", ""), "Full Name"),
        "email": validate_email(data.get("email", "")),
        "phone": validate_phone(data.get("phone", "")),
        "password": pw,
        "city": validate_city(data.get("city", "")),
        "area": validate_area(data.get("area", "")),
    }


def validate_donor_registration(data: dict) -> dict:
    
    pw = validate_password(data.get("password", "donor123"))

    return {
        "full_name": validate_name(data.get("full_name", ""), "Full Name"),
        "email": validate_email(data.get("email", "")),
        "phone": validate_phone(data.get("phone", "")),
        "password": pw,
        "blood_group": validate_blood_group(data.get("blood_group", "")),
        "age": validate_age(data.get("age", "")),
        "city": validate_city(data.get("city", "")),
        "area": validate_area(data.get("area", "")),
        "last_donation_date": validate_date(data.get("last_donation_date", "")),
        "availability": "Available" if data.get("availability", "").strip().lower() != "unavailable" else "Unavailable",
    }

validate_donor_data = validate_donor_registration


def validate_emergency_data(data: dict) -> dict:
    try:
        units = int(data.get("units_required", 1))
    except (ValueError, TypeError):
        raise ValidationError("Units required must be an integer.", "units_required")

    if units <= 0 or units > 20:
        raise ValidationError("Units required must be between 1 and 20 units.", "units_required")

    level = data.get("emergency_level", "High").strip().capitalize()
    if level not in {"Critical", "High", "Medium", "Normal"}:
        level = "High"

    message = data.get("message", "Urgent blood requirement").strip() or "Urgent blood requirement for patient."

    return {
        "patient_name": validate_name(data.get("patient_name", ""), "Patient Name"),
        "required_blood_group": validate_blood_group(data.get("required_blood_group", "")),
        "hospital_name": validate_name(data.get("hospital_name", ""), "Hospital Name"),
        "city": validate_city(data.get("city", "")),
        "area": validate_area(data.get("area", "")),
        "contact_number": validate_phone(data.get("contact_number", "")),
        "units_required": units,
        "emergency_level": level,
        "status": data.get("status", "Pending").strip().capitalize() or "Pending",
        "message": message[:250],
        "requester_email": data.get("requester_email", "general@bloodconnect.org").strip().lower(),
    }


def validate_search_input(data: dict) -> dict:
    blood_group = data.get("blood_group", "").strip().upper()
    city = data.get("city", "").strip()
    area = data.get("area", "").strip()

    if blood_group and blood_group not in VALID_BLOOD_GROUPS_SET:
        raise ValidationError(f"Invalid blood group filter: {blood_group}", "blood_group")

    clean_city = SEARCH_REGEX.sub("", city).strip() if city else ""
    clean_area = SEARCH_REGEX.sub("", area).strip() if area else ""

    return {
        "blood_group": blood_group,
        "city": clean_city,
        "area": clean_area,
    }
