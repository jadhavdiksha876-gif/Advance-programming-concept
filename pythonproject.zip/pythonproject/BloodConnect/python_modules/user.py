import hashlib
import time


def hash_password(password: str) -> str:
    
    if not password:
        return ""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hash_password(plain_password) == hashed_password

class User:
   

    def __init__(
        self,
        user_id: str,
        full_name: str,
        email: str,
        phone: str,
        password_hash: str,
        city: str = "",
        area: str = "",
        created_at: str = "",
    ):
        
        self.user_id = str(user_id).strip()
        self.full_name = str(full_name).strip()
        self.email = str(email).strip().lower()
        self.phone = str(phone).strip()
        self.password_hash = str(password_hash).strip()
        self.city = str(city).strip()
        self.area = str(area).strip()
        self.created_at = str(created_at).strip() if created_at else time.strftime("%Y-%m-%d")

    def check_password(self, password: str) -> bool:
        return verify_password(password, self.password_hash)

    def get_contact_info(self) -> str:
        """Returns formatted string of user contact."""
        return f"{self.full_name} | {self.phone} | {self.email}"

    def update_profile(self, *args, **kwargs):
       
        if len(args) == 1:
            self.city = str(args[0]).strip()
        elif len(args) == 2:
            self.city = str(args[0]).strip()
            self.area = str(args[1]).strip()
        elif len(args) >= 3:
            self.city = str(args[0]).strip()
            self.area = str(args[1]).strip()
            self.phone = str(args[2]).strip()

        if "city" in kwargs and kwargs["city"]:
            self.city = str(kwargs["city"]).strip()
        if "area" in kwargs and kwargs["area"]:
            self.area = str(kwargs["area"]).strip()
        if "phone" in kwargs and kwargs["phone"]:
            self.phone = str(kwargs["phone"]).strip()
        if "full_name" in kwargs and kwargs["full_name"]:
            self.full_name = str(kwargs["full_name"]).strip()
        return self

    def display_profile(self) -> dict:
        return {
            "user_id": self.user_id,
            "full_name": self.full_name,
            "email": self.email,
            "phone": self.phone,
            "city": self.city,
            "area": self.area,
            "role": "Normal User",
            "created_at": self.created_at,
        }

    def to_file_record(self) -> str:
        fields = [
            self.user_id,
            self.full_name,
            self.email,
            self.phone,
            self.password_hash,
            self.city,
            self.area,
            self.created_at,
        ]
        return "|".join(fields) + "\n"


class UserService:

    @staticmethod
    def authenticate(email: str, plain_password: str):
        from python_modules.file_manager import FileManager

        clean_email = email.strip().lower()
        users = FileManager.read_users()
        for user in users:
            if user.email == clean_email:
                if user.check_password(plain_password):
                    return user
        return None

    @staticmethod
    def register(form_data: dict) -> User:
       
        from python_modules.file_manager import FileManager
        from python_modules.validation import validate_user_registration, ValidationError

        validated = validate_user_registration(form_data)
        users = FileManager.read_users()

        
        if any(u.email == validated["email"] for u in users):
            raise ValidationError("This email address is already registered as a user.", "email")

    
        max_num = 100
        for u in users:
            if u.user_id.startswith("USR") and u.user_id[3:].isdigit():
                max_num = max(max_num, int(u.user_id[3:]))
        new_id = f"USR{max_num + 1}"

        pw_hash = hash_password(validated["password"])
        new_user = User(
            user_id=new_id,
            full_name=validated["full_name"],
            email=validated["email"],
            phone=validated["phone"],
            password_hash=pw_hash,
            city=validated["city"],
            area=validated["area"],
        )
        FileManager.append_user(new_user)
        return new_user

    @staticmethod
    def get_by_id(user_id: str):
        """Finds user by user_id."""
        from python_modules.file_manager import FileManager

        users = FileManager.read_users()
        clean_id = user_id.strip()
        for user in users:
            if user.user_id == clean_id:
                return user
        return None

    @staticmethod
    def get_by_email(email: str):
        """Finds user by email."""
        from python_modules.file_manager import FileManager

        clean_email = email.strip().lower()
        users = FileManager.read_users()
        for user in users:
            if user.email == clean_email:
                return user
        return None
