import os
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHARTS_DIR = os.path.join(BASE_DIR, "reports", "charts")

PALETTE = {
    "red_primary": "#d32f2f",
    "red_dark": "#b71c1c",
    "navy_primary": "#10263d",
    "navy_light": "#274b74",
    "green_success": "#2e7d32",
    "coral": "#e63946",
    "amber": "#f59e0b",
    "gray_light": "#f1f5f9",
    "grid_color": "#e2e8f0",
}


class AnalyticsEngine:
    
    @staticmethod
    def ensure_charts_directory() -> None:
        """Ensures the reports/charts directory exists."""
        os.makedirs(CHARTS_DIR, exist_ok=True)

    # Topic 27: Pandas - DataFrame Conversions
    
    @staticmethod
    def build_donor_dataframe(donors: list) -> pd.DataFrame:
       
        if not donors:
            return pd.DataFrame(
                columns=[
                    "Donor ID",
                    "Name",
                    "Age",
                    "Blood Group",
                    "City",
                    "Area",
                    "Availability",
                    "Last Donation",
                ]
            )

        rows = []
        for donor in donors:
            # Topic 10: Dictionaries
            rows.append(
                {
                    "Donor ID": donor.user_id,
                    "Name": donor.full_name,
                    "Age": donor.age,
                    "Blood Group": donor.blood_group,
                    "City": donor.city,
                    "Area": donor.area,
                    "Availability": donor.availability,
                    "Last Donation": donor.last_donation_date,
                }
            )

        # Topic 27: Pandas DataFrame
        df = pd.DataFrame(rows)
        return df

    @staticmethod
    def build_emergency_dataframe(requests: list) -> pd.DataFrame:
        
        if not requests:
            return pd.DataFrame(
                columns=[
                    "Request ID",
                    "Patient",
                    "Blood Group",
                    "Hospital",
                    "City",
                    "Units",
                    "Level",
                    "Status",
                ]
            )

        rows = []
        for req in requests:
            rows.append(
                {
                    "Request ID": req.request_id,
                    "Patient": req.patient_name,
                    "Blood Group": req.required_blood_group,
                    "Hospital": req.hospital_name,
                    "City": req.city,
                    "Units": req.units_required,
                    "Level": req.emergency_level,
                    "Status": req.status,
                }
            )

        return pd.DataFrame(rows)

    # Topic 25: NumPy - Numerical & Statistical Calculations
    @staticmethod
    def compute_summary_statistics(donors: list, requests: list) -> dict:

        donor_count = len(donors)
        request_count = len(requests)

        # Extract ages for NumPy calculations
        if donors:
            # Topic 25: NumPy - Vectorized array creation
            age_array = np.array([donor.age for donor in donors], dtype=np.float64)
            avg_age = round(float(np.mean(age_array)), 1)
            median_age = round(float(np.median(age_array)), 1)
            std_age = round(float(np.std(age_array)), 1)
            min_age = int(np.min(age_array))
            max_age = int(np.max(age_array))
        else:
            avg_age = 0.0
            median_age = 0.0
            std_age = 0.0
            min_age = 0
            max_age = 0

        # Topic 4: Control Statements & comprehension
        available_donors = sum(1 for d in donors if d.availability.lower() == "available")
        unavailable_donors = donor_count - available_donors
        open_requests = sum(1 for r in requests if r.status.lower() == "pending")
        fulfilled_requests = request_count - open_requests

        # Topic 9: Sets - Unique cities count
        unique_cities_count = len({d.city for d in donors if d.city})

        return {
            "total_donors": donor_count,
            "available_donors": available_donors,
            "unavailable_donors": unavailable_donors,
            "availability_rate": round((available_donors / donor_count * 100), 1) if donor_count > 0 else 0.0,
            "average_age": avg_age,
            "median_age": median_age,
            "std_age": std_age,
            "min_age": min_age,
            "max_age": max_age,
            "total_requests": request_count,
            "open_requests": open_requests,
            "fulfilled_requests": fulfilled_requests,
            "unique_cities_count": unique_cities_count,
        }

    # Topic 26: Matplotlib - Professional Chart Generation
    @staticmethod
    def generate_all_charts(donors: list, requests: list) -> dict:

        AnalyticsEngine.ensure_charts_directory()
        donor_df = AnalyticsEngine.build_donor_dataframe(donors)
        emergency_df = AnalyticsEngine.build_emergency_dataframe(requests)

        chart_files = {
            "blood_group_dist": os.path.join(CHARTS_DIR, "blood_group_dist.png"),
            "city_donor_count": os.path.join(CHARTS_DIR, "city_donor_count.png"),
            "availability_ratio": os.path.join(CHARTS_DIR, "availability_ratio.png"),
            "emergency_stats": os.path.join(CHARTS_DIR, "emergency_stats.png"),
        }


        try:
            plt.figure(figsize=(8, 4.8), dpi=150)
            all_groups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]

            if not donor_df.empty and "Blood Group" in donor_df.columns:
                counts_series = donor_df["Blood Group"].value_counts()
                # Reindex to guarantee all 8 groups appear
                counts = [int(counts_series.get(bg, 0)) for bg in all_groups]
            else:
                counts = [0] * len(all_groups)

            bars = plt.bar(
                all_groups,
                counts,
                color=PALETTE["red_primary"],
                edgecolor=PALETTE["red_dark"],
                linewidth=1.2,
                width=0.55,
            )

            # Add count labels on top of bars
            for bar in bars:
                height = bar.get_height()
                plt.text(
                    bar.get_x() + bar.get_width() / 2.0,
                    height + 0.1,
                    f"{int(height)}",
                    ha="center",
                    va="bottom",
                    fontweight="bold",
                    color=PALETTE["navy_primary"],
                    fontsize=9,
                )

            plt.title("Donor Count by Blood Group", fontsize=13, fontweight="bold", pad=15, color=PALETTE["navy_primary"])
            plt.xlabel("Blood Group", fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.ylabel("Registered Donors", fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.grid(axis="y", linestyle="--", alpha=0.5, color=PALETTE["grid_color"])
            plt.ylim(0, max(counts + [3]) + 1)
            plt.tight_layout()
            plt.savefig(chart_files["blood_group_dist"])
            plt.close()
        except Exception as exc:
            print(f"[Analytics] Error generating blood_group_dist: {exc}")
            plt.close()

       
        try:
            plt.figure(figsize=(8, 4.8), dpi=150)
            if not donor_df.empty and "City" in donor_df.columns:
                city_counts = donor_df["City"].value_counts().head(7).sort_values(ascending=True)
                cities = city_counts.index.tolist()
                counts = city_counts.values.tolist()
            else:
                cities = ["No Data"]
                counts = [0]

            y_pos = np.arange(len(cities))
            bars = plt.barh(
                y_pos,
                counts,
                color=PALETTE["navy_primary"],
                edgecolor=PALETTE["navy_light"],
                height=0.55,
            )

            for bar in bars:
                width = bar.get_width()
                plt.text(
                    width + 0.1,
                    bar.get_y() + bar.get_height() / 2.0,
                    f"{int(width)}",
                    ha="left",
                    va="center",
                    fontweight="bold",
                    color=PALETTE["navy_primary"],
                    fontsize=9,
                )

            plt.yticks(y_pos, cities, fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.title("Top Cities by Registered Donors", fontsize=13, fontweight="bold", pad=15, color=PALETTE["navy_primary"])
            plt.xlabel("Donor Count", fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.grid(axis="x", linestyle="--", alpha=0.5, color=PALETTE["grid_color"])
            plt.xlim(0, max(counts + [3]) + 1.2)
            plt.tight_layout()
            plt.savefig(chart_files["city_donor_count"])
            plt.close()
        except Exception as exc:
            print(f"[Analytics] Error generating city_donor_count: {exc}")
            plt.close()

        
        try:
            plt.figure(figsize=(6, 4.8), dpi=150)
            available_count = sum(1 for d in donors if d.availability.lower() == "available")
            unavailable_count = len(donors) - available_count

            if available_count == 0 and unavailable_count == 0:
                labels = ["No Donors"]
                sizes = [1]
                colors = ["#cbd5e1"]
            else:
                labels = [f"Available ({available_count})", f"Unavailable ({unavailable_count})"]
                sizes = [available_count, unavailable_count]
                colors = [PALETTE["green_success"], PALETTE["coral"]]

            wedges, texts, autotexts = plt.pie(
                sizes,
                labels=labels,
                autopct="%1.1f%%" if (available_count + unavailable_count > 0) else "",
                startangle=140,
                colors=colors,
                wedgeprops=dict(width=0.45, edgecolor="white", linewidth=2),
                textprops=dict(color=PALETTE["navy_primary"], fontweight="bold"),
            )
            for autotext in autotexts:
                autotext.set_color("white")
                autotext.set_fontsize(10)

            plt.title("Donor Availability Ratio", fontsize=13, fontweight="bold", pad=15, color=PALETTE["navy_primary"])
            plt.tight_layout()
            plt.savefig(chart_files["availability_ratio"])
            plt.close()
        except Exception as exc:
            print(f"[Analytics] Error generating availability_ratio: {exc}")
            plt.close()

        
        try:
            plt.figure(figsize=(8, 4.8), dpi=150)
            if not emergency_df.empty and "Blood Group" in emergency_df.columns:
                emg_counts = emergency_df["Blood Group"].value_counts().sort_index()
                groups = emg_counts.index.tolist()
                counts = emg_counts.values.tolist()
            else:
                groups = ["None"]
                counts = [0]

            bars = plt.bar(
                groups,
                counts,
                color=PALETTE["amber"],
                edgecolor="#b45309",
                width=0.55,
                linewidth=1.2,
            )

            for bar in bars:
                height = bar.get_height()
                plt.text(
                    bar.get_x() + bar.get_width() / 2.0,
                    height + 0.05,
                    f"{int(height)}",
                    ha="center",
                    va="bottom",
                    fontweight="bold",
                    color=PALETTE["navy_primary"],
                    fontsize=9,
                )

            plt.title("Emergency Requests by Blood Group", fontsize=13, fontweight="bold", pad=15, color=PALETTE["navy_primary"])
            plt.xlabel("Blood Group Required", fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.ylabel("Emergency Cases", fontsize=10, fontweight="bold", color=PALETTE["navy_primary"])
            plt.grid(axis="y", linestyle="--", alpha=0.5, color=PALETTE["grid_color"])
            plt.ylim(0, max(counts + [3]) + 1)
            plt.tight_layout()
            plt.savefig(chart_files["emergency_stats"])
            plt.close()
        except Exception as exc:
            print(f"[Analytics] Error generating emergency_stats: {exc}")
            plt.close()

        return chart_files
