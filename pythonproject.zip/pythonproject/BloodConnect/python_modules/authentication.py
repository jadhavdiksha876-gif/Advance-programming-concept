import hashlib
import time
from http.cookies import SimpleCookie

from python_modules.user import hash_password, verify_password
from python_modules.file_manager import FileManager

SESSION_STORE = {}


def generate_session_token(user_id: str) -> str:
    """Generates a pseudo-random session token using SHA-256 and timestamp."""
    seed = f"{user_id}:{time.time()}:bloodconnect_secret"
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()[:32]


def create_session(user_id: str, role: str, email: str, name: str) -> str:
    
    token = generate_session_token(user_id)
    SESSION_STORE[token] = {
        "user_id": user_id,
        "role": role.lower().strip(),  # 'user', 'donor', or 'admin'
        "email": email.lower().strip(),
        "name": name.strip(),
        "login_time": time.time(),
    }
    return token


def get_session(token: str):
   
    if not token:
        return None
    return SESSION_STORE.get(token)


def delete_session(token: str) -> None:
    
    if token in SESSION_STORE:
        del SESSION_STORE[token]


def extract_session_token_from_headers(headers) -> str:
    
    cookie_header = headers.get("Cookie", "")
    if not cookie_header:
        return ""
    try:
        cookie = SimpleCookie()
        cookie.load(cookie_header)
        if "bloodconnect_session" in cookie:
            return cookie["bloodconnect_session"].value
    except Exception:
        return ""
    return ""


def get_current_user_from_headers(headers):
    """Helper to get logged-in user dict from HTTP request headers."""
    token = extract_session_token_from_headers(headers)
    return get_session(token)


def build_set_cookie_header(token: str) -> str:
    
    return f"bloodconnect_session={token}; Path=/; HttpOnly; SameSite=Lax"


def build_clear_cookie_header() -> str:
    return "bloodconnect_session=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT"


def get_dashboard_url_for_role(role: str) -> str:
    clean_role = str(role).strip().lower()
    if clean_role == "user":
        return "/user_dashboard.html"
    elif clean_role == "donor":
        return "/donor_dashboard.html"
    elif clean_role == "admin":
        return "/admin_dashboard.html"
    return "/select_role.html"


def verify_role_access(headers, required_role: str):
    
    session = get_current_user_from_headers(headers)
    clean_required = required_role.strip().lower()

    if not session:
       
        login_page = f"/{clean_required}_login.html"
        return None, f"{login_page}?msg=Please+sign+in+to+continue."

    session_role = session.get("role", "").lower().strip()
    if session_role != clean_required:
        return None, f"/{clean_required}_login.html?msg=Access+denied.+This+area+requires+{clean_required.upper()}+privileges."

    return session, None


def authenticate_user(email: str, plain_password: str):
    
    from python_modules.user import UserService

    return UserService.authenticate(email, plain_password)


def authenticate_donor(email: str, plain_password: str):
    
    from python_modules.donor import DonorService

    return DonorService.authenticate(email, plain_password)


def authenticate_admin(username: str, plain_password: str):
   
    from python_modules.admin import AdminService

    return AdminService.authenticate(username, plain_password)
