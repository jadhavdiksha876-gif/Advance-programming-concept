import time

VALID_EMERGENCY_LEVELS = ("Critical", "High", "Medium", "Normal")
VALID_REQUEST_STATUSES = ("Pending", "Reviewing", "Donor Found", "Completed")


PRIORITY_WEIGHTS = {
    "Critical": 1,
    "High": 2,
    "Medium": 3,
    "Normal": 4,
}



class EmergencyRequest:
   

    def __init__(
        self,
        request_id: str,
        patient_name: str,
        required_blood_group: str,
        hospital_name: str,
        city: str,
        area: str,
        contact_number: str,
        units_required: int,
        emergency_level: str = "High",
        status: str = "Pending",
        message: str = "Urgent blood requirement",
        requester_email: str = "general@bloodconnect.org",
        created_at: str = "",
    ):
        self.request_id = str(request_id).strip()
        self.patient_name = str(patient_name).strip()
        self.required_blood_group = str(required_blood_group).strip().upper()
        self.hospital_name = str(hospital_name).strip()
        self.city = str(city).strip()
        self.area = str(area).strip()
        self.contact_number = str(contact_number).strip()
        self.units_required = int(units_required)
        self.emergency_level = str(emergency_level).strip()
        self.status = str(status).strip() if status else "Pending"
        self.message = str(message).strip()
        self.requester_email = str(requester_email).strip().lower()
        self.created_at = str(created_at).strip() if created_at else time.strftime("%Y-%m-%d")

    def display_profile(self) -> dict:
        
        return {
            "request_id": self.request_id,
            "patient_name": self.patient_name,
            "required_blood_group": self.required_blood_group,
            "hospital_name": self.hospital_name,
            "city": self.city,
            "area": self.area,
            "contact_number": self.contact_number,
            "units_required": self.units_required,
            "emergency_level": self.emergency_level,
            "status": self.status,
            "message": self.message,
            "requester_email": self.requester_email,
            "created_at": self.created_at,
            "is_critical": self.emergency_level.lower() == "critical",
            "is_pending": self.status.lower() in ("pending", "reviewing"),
        }

    def to_file_record(self) -> str:
        
        fields = [
            self.request_id,
            self.patient_name,
            self.required_blood_group,
            self.hospital_name,
            self.city,
            self.area,
            self.contact_number,
            str(self.units_required),
            self.emergency_level,
            self.status,
            self.message,
            self.requester_email,
            self.created_at,
        ]
        return "|".join(fields) + "\n"


class EmergencyService:
    

    
    @staticmethod
    def sort_by_urgency(requests_list: list) -> list:
        
        return sorted(
            requests_list,
            key=lambda req: (
                0 if req.status.lower() in ("pending", "reviewing") else 1,
                PRIORITY_WEIGHTS.get(req.emergency_level, 99),
                -req.units_required,
            ),
        )

    @staticmethod
    def filter_by_user(requests_list: list, user_email: str) -> list:
    
        clean_email = str(user_email).strip().lower()
        return [r for r in requests_list if r.requester_email.lower() == clean_email]
