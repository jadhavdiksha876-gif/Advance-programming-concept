import os
import array

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

USERS_FILE = os.path.join(DATA_DIR, "users.txt")
DONORS_FILE = os.path.join(DATA_DIR, "donors.txt")
EMERGENCY_FILE = os.path.join(DATA_DIR, "emergency_requests.txt")
ADMINS_FILE = os.path.join(DATA_DIR, "admins.txt")


class FileManager:
    
    USERS_FILE = USERS_FILE
    DONORS_FILE = DONORS_FILE
    EMERGENCY_FILE = EMERGENCY_FILE
    ADMINS_FILE = ADMINS_FILE

    @staticmethod
    def ensure_data_directories() -> None:
        
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            for file_path in (USERS_FILE, DONORS_FILE, EMERGENCY_FILE, ADMINS_FILE):
                if not os.path.exists(file_path):
                    with open(file_path, "w", encoding="utf-8") as file:
                        file.write("")
        except OSError as exc:
            raise IOError(f"Failed to initialize data directories: {exc}") from exc

   

    @staticmethod
    def append_user(user) -> None:
        """Appends user record to users.txt."""
        FileManager.ensure_data_directories()
        with open(USERS_FILE, "a", encoding="utf-8") as file:
            file.write(user.to_file_record())

    @staticmethod
    def read_users() -> list:
        """Reads all normal users from users.txt."""
        from python_modules.user import User

        FileManager.ensure_data_directories()
        users = []
        try:
            with open(USERS_FILE, "r", encoding="utf-8") as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue
                    chunks = line.split("|")
                    if len(chunks) >= 8:
                        (
                            user_id,
                            name,
                            email,
                            phone,
                            pw_hash,
                            city,
                            area,
                            created_at,
                        ) = chunks[:8]
                        users.append(
                            User(
                                user_id=user_id,
                                full_name=name,
                                email=email,
                                phone=phone,
                                password_hash=pw_hash,
                                city=city,
                                area=area,
                                created_at=created_at,
                            )
                        )
        except FileNotFoundError:
            return []
        return users

    @staticmethod
    def write_users(users_list: list) -> None:
        FileManager.ensure_data_directories()
        with open(USERS_FILE, "w", encoding="utf-8") as file:
            for u in users_list:
                file.write(u.to_file_record())

    @staticmethod
    def delete_user(user_id: str) -> bool:
        users = FileManager.read_users()
        initial_len = len(users)
        remaining = [u for u in users if u.user_id != user_id]
        if len(remaining) < initial_len:
            FileManager.write_users(remaining)
            return True
        return False

    @staticmethod
    def find_user_by_email_or_id(query: str):
        """Finds user by email or ID."""
        cleaned = query.strip().lower()
        for u in FileManager.read_users():
            if u.user_id.lower() == cleaned or u.email.lower() == cleaned:
                return u
        return None


    @staticmethod
    def append_donor(donor) -> None:
        """Appends donor record to donors.txt."""
        FileManager.ensure_data_directories()
        with open(DONORS_FILE, "a", encoding="utf-8") as file:
            file.write(donor.to_file_record())

    @staticmethod
    def read_donors() -> list:
        """Reads all donors from donors.txt."""
        from python_modules.donor import Donor

        FileManager.ensure_data_directories()
        donors = []
        try:
            with open(DONORS_FILE, "r", encoding="utf-8") as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue
                    chunks = line.split("|")
                    if len(chunks) >= 11:
                        (
                            donor_id,
                            name,
                            email,
                            phone,
                            pw_hash,
                            blood_group,
                            age,
                            city,
                            area,
                            last_donation,
                            availability,
                        ) = chunks[:11]
                        donor_obj = Donor(
                            donor_id=donor_id,
                            full_name=name,
                            email=email,
                            phone=phone,
                            password_hash=pw_hash,
                            blood_group=blood_group,
                            age=int(age),
                            city=city,
                            area=area,
                            last_donation_date=last_donation,
                            availability=availability,
                        )
                        donors.append(donor_obj)
        except FileNotFoundError:
            return []
        return donors

    @staticmethod
    def write_donors(donors_list: list) -> None:
        """Overwrites donors.txt."""
        FileManager.ensure_data_directories()
        with open(DONORS_FILE, "w", encoding="utf-8") as file:
            for d in donors_list:
                file.write(d.to_file_record())

    @staticmethod
    def update_donor(donor_id: str, **kwargs) -> bool:
        """Updates fields of an existing donor and persists to file."""
        donors = FileManager.read_donors()
        found = False
        for d in donors:
            if d.user_id == donor_id:
                d.update_profile(**kwargs)
                found = True
                break
        if found:
            FileManager.write_donors(donors)
        return found

    @staticmethod
    def delete_donor(donor_id: str) -> bool:
        """Deletes a donor by ID."""
        donors = FileManager.read_donors()
        initial_len = len(donors)
        remaining = [d for d in donors if d.user_id != donor_id]
        if len(remaining) < initial_len:
            FileManager.write_donors(remaining)
            return True
        return False

    @staticmethod
    def find_donor_by_id_or_phone(query: str):
        """Finds donor by ID, email, or phone."""
        cleaned = query.strip().lower()
        for d in FileManager.read_donors():
            if d.user_id.lower() == cleaned or d.phone == cleaned or d.email.lower() == cleaned:
                return d
        return None

    
    @staticmethod
    def get_donor_ages_array() -> array.array:
        """Stores donor ages in a signed integer array ('i')."""
        donors = FileManager.read_donors()
        return array.array("i", [d.age for d in donors])


    @staticmethod
    def get_unique_cities() -> set:
        return {d.city for d in FileManager.read_donors() if d.city}


    @staticmethod
    def append_emergency_request(request) -> None:
        """Appends emergency request to emergency_requests.txt."""
        FileManager.ensure_data_directories()
        with open(EMERGENCY_FILE, "a", encoding="utf-8") as file:
            file.write(request.to_file_record())

    @staticmethod
    def read_emergency_requests() -> list:
        """Reads all emergency requests from emergency_requests.txt."""
        from python_modules.emergency import EmergencyRequest

        FileManager.ensure_data_directories()
        requests = []
        try:
            with open(EMERGENCY_FILE, "r", encoding="utf-8") as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue
                    chunks = line.split("|")
                    if len(chunks) >= 10:
                        request_id = chunks[0]
                        patient_name = chunks[1]
                        blood_group = chunks[2]
                        hospital = chunks[3]
                        city = chunks[4]
                        area = chunks[5] if len(chunks) >= 13 else "Central"
                        contact = chunks[6] if len(chunks) >= 13 else chunks[5]
                        units = int(chunks[7] if len(chunks) >= 13 else chunks[6])
                        level = chunks[8] if len(chunks) >= 13 else chunks[7]
                        status = chunks[9] if len(chunks) >= 13 else chunks[8]
                        message = chunks[10] if len(chunks) >= 13 else chunks[9]
                        requester_email = chunks[11] if len(chunks) >= 13 else "general@bloodconnect.org"
                        created_at = chunks[12] if len(chunks) >= 13 else "2024-03-20"

                        req = EmergencyRequest(
                            request_id=request_id,
                            patient_name=patient_name,
                            required_blood_group=blood_group,
                            hospital_name=hospital,
                            city=city,
                            area=area,
                            contact_number=contact,
                            units_required=units,
                            emergency_level=level,
                            status=status,
                            message=message,
                            requester_email=requester_email,
                            created_at=created_at,
                        )
                        requests.append(req)
        except FileNotFoundError:
            return []
        return requests

    @staticmethod
    def write_emergency_requests(requests_list: list) -> None:
        """Overwrites emergency_requests.txt."""
        FileManager.ensure_data_directories()
        with open(EMERGENCY_FILE, "w", encoding="utf-8") as file:
            for r in requests_list:
                file.write(r.to_file_record())

    @staticmethod
    def update_request_status(request_id: str, new_status: str) -> bool:
        """Updates status of an emergency request."""
        requests = FileManager.read_emergency_requests()
        found = False
        for r in requests:
            if r.request_id == request_id:
                r.status = new_status.strip()
                found = True
                break
        if found:
            FileManager.write_emergency_requests(requests)
        return found

    @staticmethod
    def delete_emergency_request(request_id: str) -> bool:
        """Deletes an emergency request by ID."""
        requests = FileManager.read_emergency_requests()
        initial_len = len(requests)
        remaining = [r for r in requests if r.request_id != request_id]
        if len(remaining) < initial_len:
            FileManager.write_emergency_requests(remaining)
            return True
        return False

    @staticmethod
    def read_admins() -> list:
        """Reads admin records from admins.txt."""
        from python_modules.admin import Admin

        FileManager.ensure_data_directories()
        admins = []
        try:
            with open(ADMINS_FILE, "r", encoding="utf-8") as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue
                    chunks = line.split("|")
                    if len(chunks) >= 5:
                        admin_id, username, pw_hash, full_name, email = chunks[:5]
                        admins.append(
                            Admin(
                                admin_id=admin_id,
                                username=username,
                                password_hash=pw_hash,
                                full_name=full_name,
                                email=email,
                            )
                        )
        except FileNotFoundError:
            return []
        return admins
