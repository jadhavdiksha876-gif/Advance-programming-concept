from python_modules.user import User

VALID_BLOOD_GROUPS = ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")

class Donor(User):

    def __init__(
        self,
        donor_id: str,
        full_name: str,
        email: str,
        phone: str,
        password_hash: str,
        blood_group: str,
        age: int,
        city: str,
        area: str,
        last_donation_date: str = "Not available",
        availability: str = "Available",
    ):
        
        super().__init__(
            user_id=donor_id,
            full_name=full_name,
            email=email,
            phone=phone,
            password_hash=password_hash,
            city=city,
            area=area,
        )

        
        self.blood_group = str(blood_group).strip().upper()
        self.age = int(age)
        self.last_donation_date = (
            str(last_donation_date).strip() if last_donation_date else "Not available"
        )
        self.availability = str(availability).strip() if availability else "Available"

   
    def update_profile(self, *args, **kwargs):
        
        super().update_profile(**kwargs)

        if len(args) == 1:
            self.availability = str(args[0]).strip()
        elif len(args) >= 2:
            self.availability = str(args[0]).strip()
            self.last_donation_date = str(args[1]).strip()

        if "availability" in kwargs and kwargs["availability"]:
            self.availability = str(kwargs["availability"]).strip()
        if "last_donation_date" in kwargs and kwargs["last_donation_date"]:
            self.last_donation_date = str(kwargs["last_donation_date"]).strip()
        if "age" in kwargs and kwargs["age"]:
            self.age = int(kwargs["age"])
        if "blood_group" in kwargs and kwargs["blood_group"]:
            self.blood_group = str(kwargs["blood_group"]).strip().upper()

        return self

    def display_profile(self) -> dict:
        
        profile = super().display_profile()
        profile.update(
            {
                "donor_id": self.user_id,
                "blood_group": self.blood_group,
                "age": self.age,
                "last_donation_date": self.last_donation_date,
                "availability": self.availability,
                "role": "Blood Donor",
                "is_available": self.availability.lower() == "available",
            }
        )
        return profile

    def get_summary(self) -> str:
        return (
            f"[Donor {self.user_id}] {self.full_name} ({self.blood_group}) - "
            f"{self.city}, {self.area} [{self.availability}]"
        )

    def to_file_record(self) -> str:
        fields = [
            self.user_id,
            self.full_name,
            self.email,
            self.phone,
            self.password_hash,
            self.blood_group,
            str(self.age),
            self.city,
            self.area,
            self.last_donation_date,
            self.availability,
        ]
        return "|".join(fields) + "\n"


class DonorService:
    

    @staticmethod
    def authenticate(email: str, plain_password: str):
       
        from python_modules.file_manager import FileManager

        clean_email = email.strip().lower()
        donors = FileManager.read_donors()
        for donor in donors:
            if donor.email == clean_email:
                if donor.check_password(plain_password):
                    return donor
        return None

    @staticmethod
    def register(form_data: dict) -> Donor:
        
        from python_modules.file_manager import FileManager
        from python_modules.validation import validate_donor_registration, ValidationError
        from python_modules.user import hash_password
        from python_modules.analytics import AnalyticsEngine

        validated = validate_donor_registration(form_data)
        donors = FileManager.read_donors()

        # Check duplicate email
        if any(d.email == validated["email"] for d in donors):
            raise ValidationError("This email address is already registered as a donor.", "email")

        # Generate sequential ID (e.g. DON116)
        max_num = 100
        for d in donors:
            if d.user_id.startswith("DON") and d.user_id[3:].isdigit():
                max_num = max(max_num, int(d.user_id[3:]))
        new_id = f"DON{max_num + 1}"

        pw_hash = hash_password(validated["password"])
        new_donor = Donor(
            donor_id=new_id,
            full_name=validated["full_name"],
            email=validated["email"],
            phone=validated["phone"],
            password_hash=pw_hash,
            blood_group=validated["blood_group"],
            age=validated["age"],
            city=validated["city"],
            area=validated["area"],
            last_donation_date=validated["last_donation_date"],
            availability=validated["availability"],
        )
        FileManager.append_donor(new_donor)
        AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
        return new_donor

    @staticmethod
    def get_by_id(donor_id: str):
        """Finds donor by donor_id or phone."""
        from python_modules.file_manager import FileManager

        return FileManager.find_donor_by_id_or_phone(donor_id)

    @staticmethod
    def get_by_email(email: str):
        """Finds donor by email."""
        from python_modules.file_manager import FileManager

        clean_email = email.strip().lower()
        donors = FileManager.read_donors()
        for donor in donors:
            if donor.email == clean_email:
                return donor
        return None

    @staticmethod
    def toggle_availability(donor_id: str, target_status: str) -> bool:
        """Toggles or sets availability for donor (Available / Unavailable)."""
        from python_modules.file_manager import FileManager
        from python_modules.analytics import AnalyticsEngine

        clean_status = "Available" if str(target_status).strip().lower() == "available" else "Unavailable"
        updated = FileManager.update_donor(donor_id, availability=clean_status)
        if updated:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
        return updated

    @staticmethod
    def update_profile(donor_id: str, **kwargs) -> bool:
        """Updates profile details for donor."""
        from python_modules.file_manager import FileManager
        from python_modules.analytics import AnalyticsEngine

        updated = FileManager.update_donor(donor_id, **kwargs)
        if updated:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
        return updated

    @staticmethod
    def get_matching_emergencies(blood_group: str) -> list:
        """Returns pending emergency requests matching donor's blood group."""
        from python_modules.file_manager import FileManager

        requests = FileManager.read_emergency_requests()
        clean_bg = blood_group.strip().upper()
        return [
            r for r in requests
            if r.required_blood_group == clean_bg and r.status.lower() in ("pending", "reviewing")
        ]
