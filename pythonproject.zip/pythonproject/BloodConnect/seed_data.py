import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from python_modules.user import User, hash_password
from python_modules.donor import Donor
from python_modules.admin import Admin
from python_modules.emergency import EmergencyRequest
from python_modules.file_manager import FileManager
from python_modules.analytics import AnalyticsEngine

# Sample Users (Password for all: user123)
SAMPLE_USERS = [
    User("USR101", "Aman Varma", "aman.varma@gmail.com", "9876500001", hash_password("user123"), "Mumbai", "Andheri East", "2024-01-10"),
    User("USR102", "Sneha Kapoor", "sneha.k@gmail.com", "9876500002", hash_password("user123"), "Delhi", "Karol Bagh", "2024-02-15"),
    User("USR103", "Ramesh Naidu", "ramesh.n@gmail.com", "9876500003", hash_password("user123"), "Bangalore", "Whitefield", "2024-03-01"),
    User("USR104", "Fatima Sheikh", "fatima.s@gmail.com", "9876500004", hash_password("user123"), "Hyderabad", "Gachibowli", "2024-03-20"),
]

# Sample Donors (Password for all: donor123)
SAMPLE_DONORS = [
    Donor("DON101", "Rahul Sharma", "rahul.sharma@gmail.com", "9876543210", hash_password("donor123"), "O+", 28, "Mumbai", "Andheri West", "2024-05-10", "Available"),
    Donor("DON102", "Priya Patel", "priya.patel@gmail.com", "9812345678", hash_password("donor123"), "A+", 24, "Delhi", "Connaught Place", "2023-11-20", "Available"),
    Donor("DON103", "Amit Verma", "amit.verma@gmail.com", "9711223344", hash_password("donor123"), "B+", 32, "Mumbai", "Bandra West", "2024-03-10", "Available"),
    Donor("DON104", "Ananya Sen", "ananya.sen@gmail.com", "9654321098", hash_password("donor123"), "O-", 29, "Bangalore", "Koramangala", "2023-08-05", "Available"),
    Donor("DON105", "Siddharth Rao", "siddharth.r@gmail.com", "9543210987", hash_password("donor123"), "AB+", 35, "Delhi", "Dwarka Sector 10", "2024-02-14", "Available"),
    Donor("DON106", "Neha Gupta", "neha.gupta@gmail.com", "9432109876", hash_password("donor123"), "A-", 26, "Mumbai", "Juhu", "2023-12-01", "Available"),
    Donor("DON107", "Vikram Singh", "vikram.singh@gmail.com", "9321098765", hash_password("donor123"), "B-", 31, "Bangalore", "Indiranagar", "2024-04-18", "Available"),
    Donor("DON108", "Kavita Reddy", "kavita.reddy@gmail.com", "9210987654", hash_password("donor123"), "AB-", 27, "Hyderabad", "Hitech City", "2024-01-30", "Unavailable"),
    Donor("DON109", "Arjun Malhotra", "arjun.m@gmail.com", "9109876543", hash_password("donor123"), "O+", 30, "Delhi", "Rohini", "2024-02-28", "Available"),
    Donor("DON110", "Pooja Joshi", "pooja.j@gmail.com", "9098765432", hash_password("donor123"), "A+", 25, "Pune", "Kothrud", "2024-03-01", "Available"),
    Donor("DON111", "Farhan Akhtar", "farhan.akhtar@gmail.com", "9823456781", hash_password("donor123"), "B+", 33, "Hyderabad", "Banjara Hills", "2024-01-12", "Available"),
    Donor("DON112", "Sunita Menon", "sunita.m@gmail.com", "9734567890", hash_password("donor123"), "O+", 29, "Chennai", "Adyar", "2023-10-05", "Available"),
    Donor("DON113", "Rohan Das", "rohan.das@gmail.com", "9645678901", hash_password("donor123"), "AB+", 36, "Kolkata", "Salt Lake", "2024-02-19", "Unavailable"),
    Donor("DON114", "Divya Nair", "divya.nair@gmail.com", "9556789012", hash_password("donor123"), "A-", 23, "Pune", "Viman Nagar", "2024-03-25", "Available"),
    Donor("DON115", "Aditya Kulkarni", "aditya.k@gmail.com", "9467890123", hash_password("donor123"), "O-", 34, "Mumbai", "Powai", "2023-09-14", "Available"),
]

# Sample Emergency Requests
SAMPLE_REQUESTS = [
    EmergencyRequest("EMG201", "Rajesh Kumar", "O+", "City Specialty Hospital", "Mumbai", "Andheri West", "9898989898", 2, "Critical", "Pending", "Urgent heart surgery scheduled at 8 AM", "aman.varma@gmail.com", "2024-03-20"),
    EmergencyRequest("EMG202", "Sunita Devi", "A-", "St. Jude Hospital", "Delhi", "Connaught Place", "9797979797", 3, "High", "Donor Found", "Dengue fever blood platelet requirement", "sneha.k@gmail.com", "2024-03-21"),
    EmergencyRequest("EMG203", "Rohan Mehta", "B+", "Apex Trauma Center", "Bangalore", "Koramangala", "9696969696", 1, "Medium", "Reviewing", "Scheduled knee replacement surgery", "ramesh.n@gmail.com", "2024-03-22"),
    EmergencyRequest("EMG204", "Meera Nair", "O-", "Apollo Hospital", "Hyderabad", "Hitech City", "9595959595", 2, "Critical", "Pending", "Emergency accident trauma care", "fatima.s@gmail.com", "2024-03-23"),
    EmergencyRequest("EMG205", "Deepak Verma", "AB+", "Fortis Healthcare", "Pune", "Kothrud", "9494949494", 4, "Critical", "Reviewing", "Major burn ICU patient needing whole blood", "aman.varma@gmail.com", "2024-03-24"),
    EmergencyRequest("EMG206", "Kiran Shrestha", "B-", "Max Super Speciality Hospital", "Delhi", "Rohini", "9393939393", 2, "High", "Completed", "Emergency internal hemorrhage treatment", "sneha.k@gmail.com", "2024-03-18"),
]

# Sample Admins (Password: admin123)
SAMPLE_ADMINS = [
    Admin("ADM001", "admin", hash_password("admin123"), "Chief Health Administrator", "admin@bloodconnect.org"),
    Admin("ADM002", "supervisor", hash_password("admin123"), "Operations Supervisor", "supervisor@bloodconnect.org"),
]


def seed():
    FileManager.ensure_data_directories()
    FileManager.write_users(SAMPLE_USERS)
    FileManager.write_donors(SAMPLE_DONORS)
    FileManager.write_emergency_requests(SAMPLE_REQUESTS)

    with open(FileManager.ADMINS_FILE, "w", encoding="utf-8") as f:
        for a in SAMPLE_ADMINS:
            f.write(a.to_file_record())

    AnalyticsEngine.generate_all_charts(SAMPLE_DONORS, SAMPLE_REQUESTS)
    print("Seeding complete:")
    print(f" - {len(SAMPLE_USERS)} Normal Users (password: user123)")
    print(f" - {len(SAMPLE_DONORS)} Blood Donors (password: donor123)")
    print(f" - {len(SAMPLE_REQUESTS)} Emergency Blood Requests")
    print(f" - {len(SAMPLE_ADMINS)} System Admins (password: admin123)")
    print(" - 4 Matplotlib Analytics Charts generated.")


if __name__ == "__main__":
    seed()
