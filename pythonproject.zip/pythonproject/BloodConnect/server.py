import os
import sys
import html
import time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import parse_qs, urlparse, unquote_plus

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from python_modules.user import User, UserService, hash_password
from python_modules.donor import Donor, DonorService
from python_modules.admin import Admin, AdminService
from python_modules.emergency import EmergencyRequest, EmergencyService
from python_modules.file_manager import FileManager
from python_modules.analytics import AnalyticsEngine
from python_modules.validation import (
    ValidationError,
    validate_user_registration,
    validate_donor_registration,
    validate_emergency_data,
    validate_search_input,
)
from python_modules.authentication import (
    create_session,
    get_session,
    delete_session,
    get_current_user_from_headers,
    extract_session_token_from_headers,
    build_set_cookie_header,
    build_clear_cookie_header,
    authenticate_user,
    authenticate_donor,
    authenticate_admin,
    verify_role_access,
    get_dashboard_url_for_role,
)



class BloodConnectHandler(SimpleHTTPRequestHandler):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)


    def do_GET(self):
        """Handles HTTP GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path
        query_params = parse_qs(parsed.query)

        # Normalize /pages/ prefixes
        if path.startswith("/pages/"):
            path = "/" + path[len("/pages/"):]

        if path in ("/", "/select_role", "/select_role.html", "/index.html", "/index"):
            self._render_select_role_page(query_params)
            return

        if path in ("/home", "/home.html"):
            self._render_home_page()
            return

        if path in ("/find_donor", "/find_donor.html"):
            self._render_find_donor_page(query_params)
            return

        if path in ("/user_login", "/user_login.html"):
            self._render_user_login_page(query_params)
            return

        if path in ("/donor_login", "/donor_login.html"):
            self._render_donor_login_page(query_params)
            return

        if path in ("/admin_login", "/admin_login.html"):
            self._render_admin_login_page(query_params)
            return

        if path in ("/user_register", "/user_register.html"):
            self._render_user_register_page(query_params)
            return

        if path in ("/donor_register", "/donor_register.html"):
            self._render_donor_register_page(query_params)
            return

        if path in ("/login", "/login.html"):
            self._send_redirect("/select_role.html")
            return

        if path in ("/register", "/register.html"):
            reg_type = query_params.get("type", [""])[0].strip().lower()
            if reg_type == "donor":
                self._send_redirect("/donor_register.html")
            else:
                self._send_redirect("/user_register.html")
            return

        if path in ("/emergency", "/emergency.html", "/emergency_request", "/emergency_request.html"):
            self._render_emergency_request_page()
            return

        if path in ("/statistics", "/statistics.html"):
            self._render_statistics_page()
            return

        if path in ("/about", "/about.html"):
            self._render_about_page()
            return

        if path in ("/user_dashboard", "/user_dashboard.html"):
            self._render_user_dashboard_page()
            return

        if path in ("/donor_dashboard", "/donor_dashboard.html"):
            self._render_donor_dashboard_page()
            return

        if path in ("/donor_profile", "/donor_profile.html"):
            self._render_donor_profile_page(query_params)
            return

        if path in ("/my_requests", "/my_requests.html"):
            self._render_my_requests_page()
            return

        if path in ("/admin", "/admin.html", "/admin_dashboard", "/admin_dashboard.html"):
            self._render_admin_dashboard_page()
            return

        if path in ("/manage_donors", "/manage_donors.html"):
            self._render_manage_donors_page(query_params)
            return

        if path in ("/manage_requests", "/manage_requests.html"):
            self._render_manage_requests_page(query_params)
            return

        if path == "/logout":
            self._process_logout()
            return

        # Static assets: CSS and Matplotlib Chart Images
        if path.startswith("/static/") or path.startswith("/reports/"):
            self._serve_static_asset(path)
            return

        # 404 Fallback
        self._serve_not_found(path)

    # --------------------------------------------------------------------------
    # Topic 23: Polymorphism - Overriding do_POST
    # --------------------------------------------------------------------------
    def do_POST(self):
        """Handles HTTP POST form submissions."""
        parsed = urlparse(self.path)
        path = parsed.path

        # Topic 3: Input and Output - Read Content-Length and payload
        content_length = int(self.headers.get("Content-Length", 0))
        post_raw = self.rfile.read(content_length).decode("utf-8")
        parsed_form = parse_qs(post_raw, keep_blank_values=True)

        # Topic 10: Dictionaries
        form_data = {k: v[0].strip() if v else "" for k, v in parsed_form.items()}

        # Role-Specific Authentication POSTs
        if path in ("/user_login", "/user_login.html"):
            self._process_user_login_post(form_data)
            return

        if path in ("/donor_login", "/donor_login.html"):
            self._process_donor_login_post(form_data)
            return

        if path in ("/admin_login", "/admin_login.html"):
            self._process_admin_login_post(form_data)
            return

        # Role-Specific Registration POSTs
        if path in ("/user_register", "/user_register.html"):
            self._process_user_register_post(form_data)
            return

        if path in ("/donor_register", "/donor_register.html"):
            self._process_donor_register_post(form_data)
            return

        # Legacy Compatibility POSTs
        if path == "/login":
            acc_type = form_data.get("account_type", "user").strip().lower()
            if acc_type == "donor":
                self._process_donor_login_post(form_data)
            else:
                self._process_user_login_post(form_data)
            return

        if path == "/register":
            reg_type = form_data.get("registration_type", "user").strip().lower()
            if reg_type == "donor":
                self._process_donor_register_post(form_data)
            else:
                self._process_user_register_post(form_data)
            return

        if path in ("/emergency", "/emergency_request", "/post_emergency"):
            self._process_emergency_request_post(form_data)
            return

        # Authenticated Updates (Donor Only)
        if path in ("/update_profile", "/donor_profile/update"):
            self._process_donor_profile_update_post(form_data)
            return

        if path == "/donor/quick_toggle":
            self._process_donor_quick_toggle(form_data)
            return

        # Admin Actions (Admin Only)
        if path == "/admin/add_donor":
            self._process_admin_add_donor(form_data)
            return

        if path == "/admin/delete_donor":
            self._process_admin_delete_donor(form_data)
            return

        if path == "/admin/toggle_donor":
            self._process_admin_toggle_donor(form_data)
            return

        if path == "/admin/delete_user":
            self._process_admin_delete_user(form_data)
            return

        if path == "/admin/update_emergency_status":
            self._process_admin_update_emergency_status(form_data)
            return

        if path == "/admin/delete_emergency":
            self._process_admin_delete_emergency(form_data)
            return

        self.send_error(404, "Unknown POST Action Endpoint")


    def _load_template(self, filename: str) -> str:
        """Loads HTML template file."""
        file_path = os.path.join(BASE_DIR, "pages", filename)
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return file.read()
        except FileNotFoundError:
            return f"<h1>Error: Template {filename} not found</h1>"

    def _send_html_response(self, html_content: str, status_code: int = 200, headers: dict = None) -> None:
        """Sends HTTP text/html response."""
        encoded = html_content.encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        if headers:
            for k, v in headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(encoded)

    def _send_redirect(self, location: str, cookie_header: str = None) -> None:
        """Sends HTTP 303 See Other redirect."""
        self.send_response(303)
        self.send_header("Location", location)
        if cookie_header:
            self.send_header("Set-Cookie", cookie_header)
        self.end_headers()

    def _serve_not_found(self, path: str) -> None:
        """Renders 404 page."""
        content = (
            "<!DOCTYPE html><html><head><title>404 Not Found</title>"
            "<link rel='stylesheet' href='/static/style.css'></head><body>"
            "<div class='container' style='text-align:center; padding: 100px 20px;'>"
            "<h1 style='font-size: 3rem; color: #d32f2f;'>404 - Page Not Found</h1>"
            f"<p>The requested URL <code>{html.escape(path)}</code> does not exist.</p>"
            "<p style='margin-top: 20px;'><a href='/' class='button button-primary'>Return to Home</a></p>"
            "</div></body></html>"
        )
        self._send_html_response(content, status_code=404)

    def _serve_static_asset(self, path: str) -> None:
        """Serves CSS and Matplotlib images."""
        safe_rel_path = path.lstrip("/")
        full_path = os.path.normpath(os.path.join(BASE_DIR, safe_rel_path))

        if not os.path.isfile(full_path):
            self.send_error(404, "Static resource not found")
            return

        content_type = "application/octet-stream"
        if full_path.endswith(".css"):
            content_type = "text/css; charset=utf-8"
        elif full_path.endswith(".png"):
            content_type = "image/png"

        with open(full_path, "rb") as file:
            data = file.read()

        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # ==========================================================================
    # Authentication & Session Helpers
    # ==========================================================================

    def _get_current_session(self):
        """Retrieves logged in session or None."""
        return get_current_user_from_headers(self.headers)

    def _build_role_nav_html(self, session, current_page: str = "") -> str:
        """Generates role-specific navigation links strictly adhering to permissions."""
        if not session:
            return (
                '<a href="/select_role.html">Select Role</a>'
                '<a href="/user_login.html">User Login</a>'
                '<a href="/donor_login.html">Donor Login</a>'
            )
        role = session.get("role")
        name = session.get("name", "User")
        if role == "user":
            c_home = ' class="active"' if current_page == 'home' else ''
            c_find = ' class="active"' if current_page == 'find_donor' else ''
            c_emg = ' class="active"' if current_page == 'emergency' else ''
            c_my = ' class="active"' if current_page == 'my_requests' else ''
            return (
                f'<a href="/user_dashboard.html"{c_home}>Home</a>'
                f'<a href="/find_donor.html"{c_find}>Find Donor</a>'
                f'<a href="/emergency_request.html"{c_emg}>Emergency Request</a>'
                f'<a href="/my_requests.html"{c_my}>My Requests</a>'
                f'<a href="/user_dashboard.html" style="font-weight: 700;">👤 {html.escape(name)}</a>'
                f'<a href="/logout" class="nav-logout">Logout</a>'
            )
        elif role == "donor":
            c_home = ' class="active"' if current_page == 'home' else ''
            c_prof = ' class="active"' if current_page == 'profile' else ''
            return (
                f'<a href="/donor_dashboard.html"{c_home}>Home</a>'
                f'<a href="/donor_profile.html"{c_prof}>My Profile</a>'
                f'<a href="/donor_dashboard.html#availability">Availability</a>'
                f'<a href="/logout" class="nav-logout">Logout</a>'
            )
        elif role == "admin":
            c_dash = ' class="active"' if current_page == 'dashboard' else ''
            c_donors = ' class="active"' if current_page == 'donors' else ''
            c_reqs = ' class="active"' if current_page == 'requests' else ''
            c_stats = ' class="active"' if current_page == 'statistics' else ''
            return (
                f'<a href="/admin_dashboard.html"{c_dash}>Dashboard</a>'
                f'<a href="/manage_donors.html"{c_donors}>Donors</a>'
                f'<a href="/manage_requests.html"{c_reqs}>Requests</a>'
                f'<a href="/statistics.html"{c_stats}>Statistics</a>'
                f'<a href="/logout" class="nav-logout">Logout</a>'
            )
        return '<a href="/select_role.html">Select Role</a>'

    def _build_auth_nav_html(self, session) -> str:
        """Backwards compatibility alias for _build_role_nav_html."""
        return self._build_role_nav_html(session)

    
    def _render_select_role_page(self, query_params: dict) -> None:
        msg = query_params.get("msg", [""])[0]
        status_html = ""
        if msg:
            status_html = f'<div class="alert info">ℹ️ {html.escape(msg)}</div>'

        content = self._load_template("select_role.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    
    def _render_home_page(self) -> None:
        session = self._get_current_session()
        if session:
            role = session.get("role")
            if role == "user":
                self._send_redirect("/user_dashboard.html")
                return
            elif role == "donor":
                self._send_redirect("/donor_dashboard.html")
                return
            elif role == "admin":
                self._send_redirect("/admin_dashboard.html")
                return
        self._send_redirect("/select_role.html")

    
    def _render_user_login_page(self, query_params: dict, status_html: str = "") -> None:
        session = self._get_current_session()
        if session and session.get("role") == "user" and not status_html and not query_params.get("msg"):
            self._send_redirect("/user_dashboard.html")
            return
        msg = query_params.get("msg", [""])[0]
        if msg and not status_html:
            status_html = f'<div class="alert info" style="background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; margin-bottom: 20px;">ℹ️ {html.escape(msg)}</div>'

        content = self._load_template("user_login.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_user_login_post(self, form_data: dict) -> None:
        email = form_data.get("email", "").strip().lower()
        password = form_data.get("password", "").strip()

        user = UserService.authenticate(email, password)
        if user:
            token = create_session(user.user_id, "user", user.email, user.full_name)
            self._send_redirect("/user_dashboard.html", cookie_header=build_set_cookie_header(token))
        else:
            status_html = '<div class="alert error">❌ Invalid User credentials. Please verify your email and password.</div>'
            self._render_user_login_page({}, status_html=status_html)

    def _render_user_register_page(self, query_params: dict, status_html: str = "") -> None:
        msg = query_params.get("msg", [""])[0]
        if msg and not status_html:
            status_html = f'<div class="alert info" style="background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; margin-bottom: 20px;">ℹ️ {html.escape(msg)}</div>'

        content = self._load_template("user_register.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_user_register_post(self, form_data: dict) -> None:
        try:
            new_user = UserService.register(form_data)
            token = create_session(new_user.user_id, "user", new_user.email, new_user.full_name)
            self._send_redirect("/user_dashboard.html", cookie_header=build_set_cookie_header(token))
        except ValidationError as err:
            status_html = f'<div class="alert error">❌ <strong>Validation Error:</strong> {html.escape(str(err))}</div>'
            self._render_user_register_page({}, status_html=status_html)
        except Exception as exc:
            status_html = f'<div class="alert error">❌ <strong>System Error:</strong> {html.escape(str(exc))}</div>'
            self._render_user_register_page({}, status_html=status_html)

    # ==========================================================================
    # 3. DONOR Authentication & Registration Controllers
    # ==========================================================================
    def _render_donor_login_page(self, query_params: dict, status_html: str = "") -> None:
        session = self._get_current_session()
        if session and session.get("role") == "donor" and not status_html and not query_params.get("msg"):
            self._send_redirect("/donor_dashboard.html")
            return
        msg = query_params.get("msg", [""])[0]
        if msg and not status_html:
            status_html = f'<div class="alert info" style="background:#fff1f2; color:#b71c1c; border:1px solid #fecdd3; margin-bottom: 20px;">ℹ️ {html.escape(msg)}</div>'

        content = self._load_template("donor_login.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_donor_login_post(self, form_data: dict) -> None:
        email = form_data.get("email", "").strip().lower()
        password = form_data.get("password", "").strip()

        donor = DonorService.authenticate(email, password)
        if donor:
            token = create_session(donor.user_id, "donor", donor.email, donor.full_name)
            self._send_redirect("/donor_dashboard.html", cookie_header=build_set_cookie_header(token))
        else:
            status_html = '<div class="alert error">❌ Invalid Blood Donor credentials. Please check your email and password.</div>'
            self._render_donor_login_page({}, status_html=status_html)

    def _render_donor_register_page(self, query_params: dict, status_html: str = "") -> None:
        msg = query_params.get("msg", [""])[0]
        if msg and not status_html:
            status_html = f'<div class="alert info" style="background:#fff1f2; color:#b71c1c; border:1px solid #fecdd3; margin-bottom: 20px;">ℹ️ {html.escape(msg)}</div>'

        content = self._load_template("donor_register.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_donor_register_post(self, form_data: dict) -> None:
        try:
            new_donor = DonorService.register(form_data)
            token = create_session(new_donor.user_id, "donor", new_donor.email, new_donor.full_name)
            self._send_redirect("/donor_dashboard.html", cookie_header=build_set_cookie_header(token))
        except ValidationError as err:
            status_html = f'<div class="alert error">❌ <strong>Validation Error:</strong> {html.escape(str(err))}</div>'
            self._render_donor_register_page({}, status_html=status_html)
        except Exception as exc:
            status_html = f'<div class="alert error">❌ <strong>System Error:</strong> {html.escape(str(exc))}</div>'
            self._render_donor_register_page({}, status_html=status_html)

    # ==========================================================================
    # 4. ADMIN Authentication Controller (Strictly No Public Admin Register)
    # ==========================================================================
    def _render_admin_login_page(self, query_params: dict, status_html: str = "") -> None:
        session = self._get_current_session()
        if session and session.get("role") == "admin" and not status_html and not query_params.get("msg"):
            self._send_redirect("/admin_dashboard.html")
            return
        msg = query_params.get("msg", [""])[0]
        if msg and not status_html:
            status_html = f'<div class="alert error">❌ {html.escape(msg)}</div>'

        content = self._load_template("admin_login.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_admin_login_post(self, form_data: dict) -> None:
        username = form_data.get("username", "").strip()
        password = form_data.get("password", "").strip()

        admin = AdminService.authenticate(username, password)
        if admin:
            token = create_session(admin.user_id, "admin", admin.email, admin.full_name)
            self._send_redirect("/admin_dashboard.html", cookie_header=build_set_cookie_header(token))
        else:
            status_html = '<div class="alert error">❌ Administrator access denied. Invalid username or password.</div>'
            self._render_admin_login_page({}, status_html=status_html)

    # ==========================================================================
    # 5. Logout Handler
    # ==========================================================================
    def _process_logout(self) -> None:
        token = extract_session_token_from_headers(self.headers)
        if token:
            delete_session(token)
        self._send_redirect("/select_role.html?msg=You+have+been+logged+out+successfully.", cookie_header=build_clear_cookie_header())

    
    def _render_login_page(self, query_params: dict, status_html: str = "") -> None:
        self._send_redirect("/select_role.html")

    def _process_login_post(self, form_data: dict) -> None:
        acc_type = form_data.get("account_type", "user").strip().lower()
        if acc_type == "donor":
            self._process_donor_login_post(form_data)
        else:
            self._process_user_login_post(form_data)

    def _render_register_page(self, query_params: dict, status_html: str = "") -> None:
        reg_type = query_params.get("type", ["user"])[0].strip().lower()
        if reg_type == "donor":
            self._render_donor_register_page(query_params, status_html)
        else:
            self._render_user_register_page(query_params, status_html)

    def _process_register_post(self, form_data: dict) -> None:
        reg_type = form_data.get("registration_type", "user").strip().lower()
        if reg_type == "donor":
            self._process_donor_register_post(form_data)
        else:
            self._process_user_register_post(form_data)

    
    def _render_user_dashboard_page(self, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "user")
        if not session:
            self._send_redirect(redirect_url)
            return

        user_name = session.get("name", "User")
        donors = FileManager.read_donors()
        avail_donors = sum(1 for d in donors if d.availability.lower() == "available")

        content = self._load_template("user_dashboard.html")
        content = content.replace("<!--USER_NAME-->", html.escape(user_name))
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--AVAILABLE_DONORS_COUNT-->", str(avail_donors))
        self._send_html_response(content)

    # ==========================================================================
    # 7. Donor Dashboard Controller (Strict Role Protected)
    # ==========================================================================
    def _render_donor_dashboard_page(self, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "donor")
        if not session:
            self._send_redirect(redirect_url)
            return

        donor = DonorService.get_by_id(session.get("user_id"))
        if not donor:
            self._send_redirect("/donor_login.html?msg=Donor+record+not+found.")
            return

        is_avail = donor.availability.lower() == "available"
        if is_avail:
            banner_html = '<p style="color: var(--success); font-weight: 600; font-size: 1.05rem;">🟢 Your profile is available for matching donors.</p>'
            avail_icon = "🟢"
            avail_text = "Available"
            toggle_action = "Unavailable"
            toggle_btn_text = "Pause My Availability"
            toggle_btn_class = "button-outline"
        else:
            banner_html = '<p style="color: var(--navy-light); font-weight: 600; font-size: 1.05rem;">⚪ Your profile is currently paused from donation calls.</p>'
            avail_icon = "⚪"
            avail_text = "Paused"
            toggle_action = "Available"
            toggle_btn_text = "Activate as Available"
            toggle_btn_class = "button-primary"

        quick_toggle_form = f"""
        <form action="/donor/quick_toggle" method="POST" style="margin: 0;">
            <input type="hidden" name="target_status" value="{toggle_action}">
            <button type="submit" class="button {toggle_btn_class} button-sm">
                {toggle_btn_text}
            </button>
        </form>
        """

        # Matching Emergency Requests for Donor's Blood Group
        requests = FileManager.read_emergency_requests()
        matching = [r for r in requests if r.required_blood_group == donor.blood_group and r.status.lower() in ("pending", "reviewing")]
        if matching:
            cards = []
            for req in matching:
                card = f"""
                <div class="donor-card" style="margin-bottom: 14px;">
                    <div class="donor-card-top">
                        <div>
                            <span class="badge {req.emergency_level.lower()}">{req.emergency_level} Urgency</span>
                            <h3 class="donor-name" style="margin-top: 6px;">{html.escape(req.patient_name)}</h3>
                            <div class="donor-loc">🏥 {html.escape(req.hospital_name)} • 📍 {html.escape(req.city)}</div>
                        </div>
                        <div class="blood-badge">{html.escape(req.required_blood_group)}</div>
                    </div>
                    <div style="font-size: 0.92rem; color: var(--navy-soft); margin: 8px 0;">"{html.escape(req.message)}"</div>
                    <div class="donor-card-bottom">
                        <span style="font-weight: 700; color: var(--primary);">💉 {req.units_required} Unit(s) Needed</span>
                        <a href="tel:{html.escape(req.contact_number)}" class="button button-sm button-primary">📞 Call {html.escape(req.contact_number)}</a>
                    </div>
                </div>
                """
                cards.append(card)
            matching_html = f'<div>{"".join(cards)}</div>'
        else:
            matching_html = '<div class="form-shell" style="text-align: center; padding: 24px;"><p style="color: var(--navy-light);">No urgent emergency requests currently match your blood type.</p></div>'

        content = self._load_template("donor_dashboard.html")
        content = content.replace("<!--DONOR_NAME-->", html.escape(donor.full_name))
        content = content.replace("<!--DONOR_STATUS_BANNER-->", banner_html)
        content = content.replace("<!--DONOR_BLOOD_GROUP-->", html.escape(donor.blood_group))
        content = content.replace("<!--DONOR_LOCATION-->", html.escape(f"{donor.area}, {donor.city}" if donor.area else donor.city))
        content = content.replace("<!--DONOR_AVAIL_ICON-->", avail_icon)
        content = content.replace("<!--DONOR_AVAIL_TEXT-->", avail_text)
        last_date = donor.last_donation_date if donor.last_donation_date != "Not available" else "None"
        content = content.replace("<!--DONOR_LAST_DATE-->", html.escape(last_date))
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--QUICK_TOGGLE_FORM-->", quick_toggle_form)
        content = content.replace("<!--MATCHING_EMERGENCIES-->", matching_html)
        self._send_html_response(content)

    def _process_donor_quick_toggle(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "donor")
        if not session:
            self._send_redirect(redirect_url)
            return
        target = form_data.get("target_status", "Available").strip()
        DonorService.toggle_availability(session.get("user_id"), target)
        status_html = f'<div class="alert success">✅ Availability updated to <strong>{html.escape(target)}</strong>.</div>'
        self._render_donor_dashboard_page(status_html=status_html)

    # ==========================================================================
    # 8. Donor Profile Page Controller
    # ==========================================================================
    def _render_donor_profile_page(self, query_params: dict, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "donor")
        if not session:
            self._send_redirect(redirect_url)
            return

        donor = DonorService.get_by_id(session.get("user_id"))
        if not donor:
            query = query_params.get("query", [""])[0].strip()
            if query:
                donor = DonorService.get_by_id(query)

        if donor:
            is_avail = donor.availability.lower() == "available"
            status_badge = '<span class="badge available">🟢 Available</span>' if is_avail else '<span class="badge unavailable">⚪ Paused</span>'

            details_html = f"""
            <div class="form-shell" style="max-width: 680px; margin: 0 auto;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border);">
                    <div>
                        <h2 style="font-size: 1.4rem; color: var(--navy);">{html.escape(donor.full_name)}</h2>
                        <div style="color: var(--navy-light); font-size: 0.92rem;">
                            Donor ID: <strong>{html.escape(donor.user_id)}</strong> | Email: {html.escape(donor.email)}
                        </div>
                    </div>
                    <div class="blood-badge" style="font-size: 1.4rem; padding: 6px 14px;">
                        {html.escape(donor.blood_group)}
                    </div>
                </div>

                <form action="/update_profile" method="POST">
                    <input type="hidden" name="donor_id" value="{html.escape(donor.user_id)}">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="phone">Phone Number *</label>
                            <input id="phone" name="phone" type="tel" value="{html.escape(donor.phone)}" required>
                        </div>

                        <div class="form-group">
                            <label for="availability">Availability Status *</label>
                            <select id="availability" name="availability">
                                <option value="Available" {"selected" if is_avail else ""}>Available</option>
                                <option value="Unavailable" {"selected" if not is_avail else ""}>Unavailable (Paused)</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="city">City *</label>
                            <input id="city" name="city" type="text" value="{html.escape(donor.city)}" required>
                        </div>

                        <div class="form-group">
                            <label for="area">Area / Locality *</label>
                            <input id="area" name="area" type="text" value="{html.escape(donor.area)}" required>
                        </div>

                        <div class="form-group form-group-full">
                            <label for="last_donation_date">Last Donation Date</label>
                            <input id="last_donation_date" name="last_donation_date" type="date" value="{html.escape(donor.last_donation_date if donor.last_donation_date != 'Not available' else '')}">
                        </div>
                    </div>

                    <div style="margin-top: 24px;">
                        <button type="submit" class="button button-primary button-block">Save Profile Changes</button>
                    </div>
                </form>
            </div>
            """
        else:
            details_html = '<div class="form-shell" style="text-align: center; padding: 40px;"><p style="color: var(--navy-light);">Donor profile not found.</p></div>'

        content = self._load_template("donor_profile.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--PROFILE_DETAILS-->", details_html)
        self._send_html_response(content)

    def _process_donor_profile_update_post(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "donor")
        if not session:
            self._send_redirect(redirect_url)
            return

        donor_id = session.get("user_id")
        phone = form_data.get("phone", "").strip()
        availability = form_data.get("availability", "").strip()
        city = form_data.get("city", "").strip()
        area = form_data.get("area", "").strip()
        last_donation_date = form_data.get("last_donation_date", "").strip() or "Not available"

        # Topic 22: Method Overloading call
        updated = DonorService.update_profile(
            donor_id,
            phone=phone,
            availability=availability,
            city=city,
            area=area,
            last_donation_date=last_donation_date,
        )

        if updated:
            status_html = f'<div class="alert success">✅ Donor profile <strong>{html.escape(donor_id)}</strong> updated successfully.</div>'
        else:
            status_html = f'<div class="alert error">❌ Donor ID {html.escape(donor_id)} not found.</div>'

        self._render_donor_profile_page({"query": [donor_id]}, status_html=status_html)

    
    def _render_find_donor_page(self, query_params: dict) -> None:
        blood_filter = query_params.get("blood_group", [""])[0].strip().upper()
        city_filter = query_params.get("city", [""])[0].strip()
        area_filter = query_params.get("area", [""])[0].strip()

        donors = FileManager.read_donors()
        matched = []

        for d in donors:
            match_blood = (not blood_filter) or (d.blood_group == blood_filter)
            match_city = (not city_filter) or (city_filter.lower() in d.city.lower())
            match_area = (not area_filter) or (area_filter.lower() in d.area.lower())
            if match_blood and match_city and match_area:
                matched.append(d)

        
        matched.sort(key=lambda d: (0 if d.availability.lower() == "available" else 1, d.full_name.lower()))

        criteria_parts = []
        if blood_filter:
            criteria_parts.append(f"Blood Group: <strong>{html.escape(blood_filter)}</strong>")
        if city_filter:
            criteria_parts.append(f"City: <strong>{html.escape(city_filter)}</strong>")
        if area_filter:
            criteria_parts.append(f"Area: <strong>{html.escape(area_filter)}</strong>")

        criteria_text = ", ".join(criteria_parts) if criteria_parts else "All Registered Donors"
        summary_html = f"""
        <div style="margin-bottom: 20px; font-size: 0.95rem; color: var(--navy-light);">
            Showing <strong>{len(matched)}</strong> donor(s) for {criteria_text}
        </div>
        """

        if matched:
            cards = []
            for d in matched:
                is_avail = d.availability.lower() == "available"
                badge_class = "available" if is_avail else "unavailable"
                badge_text = "Available" if is_avail else "Unavailable"

                card = f"""
                <div class="donor-card">
                    <div class="donor-card-top">
                        <div>
                            <h3 class="donor-name">{html.escape(d.full_name)}</h3>
                            <div class="donor-location">📍 {html.escape(d.area)}, {html.escape(d.city)}</div>
                        </div>
                        <div class="blood-badge">{html.escape(d.blood_group)}</div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding-top: 12px; border-top: 1px solid var(--border);">
                        <span class="badge {badge_class}">{badge_text}</span>
                        <a href="tel:{html.escape(d.phone)}" class="button button-primary button-sm">📞 {html.escape(d.phone)}</a>
                    </div>
                </div>
                """
                cards.append(card)
            results_html = f'<div class="donor-grid">{"".join(cards)}</div>'
        else:
            results_html = """
            <div style="text-align: center; padding: 48px 24px; background: var(--surface); border-radius: var(--radius); border: 1px dashed var(--border);">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">🔍</div>
                <h3 style="color: var(--navy); margin-bottom: 6px;">No Donors Found</h3>
                <p style="color: var(--navy-light); font-size: 0.95rem;">Try clearing the search filters or searching a nearby city.</p>
            </div>
            """

        session = self._get_current_session()
        content = self._load_template("find_donor.html")
        content = content.replace("<!--ROLE_NAV-->", self._build_role_nav_html(session, "find_donor"))
        content = content.replace("<!--USER_AUTH_NAV-->", self._build_role_nav_html(session, "find_donor"))
        content = content.replace("<!--STATUS_MESSAGE-->", "")
        content = content.replace("<!--SEARCH_SUMMARY-->", summary_html)
        content = content.replace("<!--RESULTS_PLACEHOLDER-->", results_html)
        self._send_html_response(content)

    # ==========================================================================
    # 10. Emergency Request Page Controller
    # ==========================================================================
    def _render_emergency_request_page(self, status_html: str = "") -> None:
        session = self._get_current_session()
        content = self._load_template("emergency_request.html")
        content = content.replace("<!--ROLE_NAV-->", self._build_role_nav_html(session, "emergency"))
        content = content.replace("<!--USER_AUTH_NAV-->", self._build_role_nav_html(session, "emergency"))
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        self._send_html_response(content)

    def _process_emergency_request_post(self, form_data: dict) -> None:
        session = self._get_current_session()
        requester_email = session.get("email") if session else "general@bloodconnect.org"

        try:
            form_data["requester_email"] = requester_email
            validated = validate_emergency_data(form_data)
            requests = FileManager.read_emergency_requests()

            max_num = 200
            for r in requests:
                if r.request_id.startswith("EMG") and r.request_id[3:].isdigit():
                    max_num = max(max_num, int(r.request_id[3:]))
            new_id = f"EMG{max_num + 1}"

            new_req = EmergencyRequest(
                request_id=new_id,
                patient_name=validated["patient_name"],
                required_blood_group=validated["required_blood_group"],
                hospital_name=validated["hospital_name"],
                city=validated["city"],
                area=validated["area"],
                contact_number=validated["contact_number"],
                units_required=validated["units_required"],
                emergency_level=validated["emergency_level"],
                status="Pending",
                message=validated["message"],
                requester_email=requester_email,
            )

            FileManager.append_emergency_request(new_req)
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())

            status_html = f"""
            <div class="alert success" style="margin-bottom: 20px;">
                ✅ <strong>Emergency Request Submitted Successfully!</strong><br>
                Request ID: <strong>{new_id}</strong> for <strong>{html.escape(new_req.patient_name)}</strong> ({html.escape(new_req.required_blood_group)} • {new_req.units_required} Units). Donors are being notified.
            </div>
            """
            self._render_emergency_request_page(status_html)

        except ValidationError as err:
            status_html = f'<div class="alert error" style="margin-bottom: 20px;">❌ <strong>Validation Error:</strong> {html.escape(str(err))}</div>'
            self._render_emergency_request_page(status_html)
        except Exception as exc:
            status_html = f'<div class="alert error" style="margin-bottom: 20px;">❌ <strong>System Error:</strong> {html.escape(str(exc))}</div>'
            self._render_emergency_request_page(status_html)

   
    def _render_my_requests_page(self) -> None:
        session, redirect_url = verify_role_access(self.headers, "user")
        if not session:
            self._send_redirect(redirect_url)
            return

        user_email = session.get("email")
        requests = FileManager.read_emergency_requests()
        my_reqs = EmergencyService.filter_by_user(requests, user_email)

        if my_reqs:
            rows = []
            for r in my_reqs:
                st = r.status.strip()
                if st.lower() == "completed":
                    badge_class = "available"
                elif st.lower() == "donor found":
                    badge_class = "info"
                else:
                    badge_class = "pending"

                row = f"""
                <tr>
                    <td><strong>{html.escape(r.request_id)}</strong></td>
                    <td><span class="blood-badge" style="font-size:0.85rem; padding: 2px 8px;">{html.escape(r.required_blood_group)}</span></td>
                    <td>{html.escape(r.hospital_name)}</td>
                    <td>{html.escape(r.city)}</td>
                    <td>{r.units_required}</td>
                    <td><span class="badge {badge_class}">{html.escape(st)}</span></td>
                </tr>
                """
                rows.append(row)
            table_html = f"""
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Blood Group</th>
                            <th>Hospital</th>
                            <th>City</th>
                            <th>Units</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>{''.join(rows)}</tbody>
                </table>
            </div>
            """
        else:
            table_html = """
            <div style="text-align: center; padding: 48px 24px; background: var(--surface); border-radius: var(--radius); border: 1px dashed var(--border);">
                <div style="font-size: 2.2rem; margin-bottom: 8px;">📋</div>
                <h3 style="color: var(--navy); margin-bottom: 6px;">No Submitted Requests</h3>
                <p style="color: var(--navy-light); font-size: 0.95rem; margin-bottom: 16px;">You haven't submitted any emergency blood requests yet.</p>
                <a href="/emergency_request.html" class="button button-primary">Request Blood Now</a>
            </div>
            """

        content = self._load_template("my_requests.html")
        content = content.replace("<!--ROLE_NAV-->", self._build_role_nav_html(session, "my_requests"))
        content = content.replace("<!--STATUS_MESSAGE-->", "")
        content = content.replace("<!--MY_REQUESTS_TABLE-->", table_html)
        self._send_html_response(content)

    # ==========================================================================
    # 12. Admin Dashboard Controller
    # ==========================================================================
    def _render_admin_dashboard_page(self, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return

        donors = FileManager.read_donors()
        users = FileManager.read_users()
        requests = FileManager.read_emergency_requests()
        stats = AnalyticsEngine.compute_summary_statistics(donors, requests)

        content = self._load_template("admin_dashboard.html")
        content = content.replace("<!--ROLE_NAV-->", self._build_role_nav_html(session, "dashboard"))
        content = content.replace("<!--ADMIN_NAME-->", html.escape(session.get("name", "Administrator")))
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--TOTAL_USERS-->", str(len(users)))
        content = content.replace("<!--TOTAL_DONORS-->", str(stats.get('total_donors', len(donors))))
        content = content.replace("<!--AVAIL_DONORS-->", str(stats.get('available_donors', 0)))
        content = content.replace("<!--EMERGENCY_REQUESTS-->", str(stats.get('open_requests', len(requests))))
        self._send_html_response(content)

    def _process_admin_delete_user(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        user_id = form_data.get("user_id", "").strip()
        deleted = AdminService.delete_user(user_id)
        if deleted:
            status_html = f'<div class="alert success">✅ User <strong>{html.escape(user_id)}</strong> removed.</div>'
        else:
            status_html = f'<div class="alert error">❌ Could not delete user {html.escape(user_id)}.</div>'
        self._render_admin_dashboard_page(status_html)

    # ==========================================================================
    # 13. Manage Donors (Admin) Controller
    # ==========================================================================
    def _render_manage_donors_page(self, query_params: dict, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return

        search_q = query_params.get("q", [""])[0].strip().lower()
        blood_filter = query_params.get("blood_group", [""])[0].strip().upper()
        city_filter = query_params.get("city", [""])[0].strip().lower()

        donors = FileManager.read_donors()
        filtered = []
        for d in donors:
            match_q = (not search_q) or (search_q in d.full_name.lower() or search_q in d.user_id.lower() or search_q in d.phone)
            match_bg = (not blood_filter) or (d.blood_group == blood_filter)
            match_city = (not city_filter) or (city_filter in d.city.lower())
            if match_q and match_bg and match_city:
                filtered.append(d)

        rows = []
        for d in filtered:
            is_avail = d.availability.lower() == "available"
            toggle_action = "Unavailable" if is_avail else "Available"
            toggle_btn_text = "Pause" if is_avail else "Activate"
            badge = '<span class="badge available">Available</span>' if is_avail else '<span class="badge unavailable">Unavailable</span>'

            row = f"""
            <tr>
                <td><strong>{html.escape(d.user_id)}</strong></td>
                <td>{html.escape(d.full_name)}</td>
                <td><span class="blood-badge" style="font-size:0.85rem; padding: 2px 8px;">{html.escape(d.blood_group)}</span></td>
                <td>{d.age}</td>
                <td>{html.escape(d.city)} ({html.escape(d.area)})</td>
                <td>{html.escape(d.phone)}</td>
                <td>{html.escape(d.email)}</td>
                <td>{html.escape(d.last_donation_date)}</td>
                <td>{badge}</td>
                <td>
                    <div style="display: flex; gap: 6px;">
                        <form action="/admin/toggle_donor" method="POST" style="margin:0;">
                            <input type="hidden" name="donor_id" value="{html.escape(d.user_id)}">
                            <input type="hidden" name="target_status" value="{toggle_action}">
                            <button type="submit" class="button button-secondary button-sm">{toggle_btn_text}</button>
                        </form>
                        <form action="/admin/delete_donor" method="POST" style="margin:0;">
                            <input type="hidden" name="donor_id" value="{html.escape(d.user_id)}">
                            <button type="submit" class="button button-danger button-sm">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            """
            rows.append(row)

        table_html = f"""
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Donor ID</th><th>Name</th><th>Blood</th><th>Age</th><th>Location</th><th>Phone</th><th>Email</th><th>Last Donation</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </div>
        """

        content = self._load_template("manage_donors.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--DONORS_TABLE-->", table_html)
        self._send_html_response(content)

    def _process_admin_add_donor(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        try:
            donor = AdminService.add_donor(form_data)
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
            status_html = f'<div class="alert success">✅ Added donor <strong>{html.escape(donor.full_name)}</strong> (ID: {donor.user_id}) successfully.</div>'
        except ValidationError as err:
            status_html = f'<div class="alert error">❌ <strong>Validation Error:</strong> {html.escape(str(err))}</div>'
        except Exception as exc:
            status_html = f'<div class="alert error">❌ <strong>System Error:</strong> {html.escape(str(exc))}</div>'
        self._render_manage_donors_page({}, status_html)

    def _process_admin_delete_donor(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        donor_id = form_data.get("donor_id", "").strip()
        deleted = AdminService.delete_donor(donor_id)
        if deleted:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
            status_html = f'<div class="alert success">✅ Donor <strong>{html.escape(donor_id)}</strong> deleted.</div>'
        else:
            status_html = f'<div class="alert error">❌ Could not delete donor {html.escape(donor_id)}.</div>'
        self._render_manage_donors_page({}, status_html)

    def _process_admin_toggle_donor(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        donor_id = form_data.get("donor_id", "").strip()
        target = form_data.get("target_status", "Available").strip()
        updated = AdminService.update_donor(donor_id, availability=target)
        if updated:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
            status_html = f'<div class="alert success">✅ Donor <strong>{html.escape(donor_id)}</strong> status changed to <strong>{html.escape(target)}</strong>.</div>'
        else:
            status_html = f'<div class="alert error">❌ Could not update donor {html.escape(donor_id)}.</div>'
        self._render_manage_donors_page({}, status_html)

    
    def _render_manage_requests_page(self, query_params: dict, status_html: str = "") -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return

        search_q = query_params.get("q", [""])[0].strip().lower()
        blood_filter = query_params.get("blood_group", [""])[0].strip().upper()
        status_filter = query_params.get("status", [""])[0].strip()

        requests = FileManager.read_emergency_requests()
        filtered = []
        for r in requests:
            match_q = (not search_q) or (search_q in r.patient_name.lower() or search_q in r.hospital_name.lower() or search_q in r.request_id.lower())
            match_bg = (not blood_filter) or (r.required_blood_group == blood_filter)
            match_status = (not status_filter) or (r.status.lower() == status_filter.lower())
            if match_q and match_bg and match_status:
                filtered.append(r)

        rows = []
        for r in filtered:
            status_options = ""
            for s in ("Pending", "Reviewing", "Donor Found", "Completed"):
                sel = "selected" if r.status == s else ""
                status_options += f'<option value="{s}" {sel}>{s}</option>'

            row = f"""
            <tr>
                <td><strong>{html.escape(r.request_id)}</strong></td>
                <td>{html.escape(r.patient_name)}</td>
                <td><span class="blood-badge" style="font-size:0.85rem; padding: 2px 8px;">{html.escape(r.required_blood_group)}</span></td>
                <td>{html.escape(r.hospital_name)}</td>
                <td>{html.escape(r.city)} ({html.escape(r.area)})</td>
                <td>{r.units_required}</td>
                <td><span class="badge {r.emergency_level.lower()}">{r.emergency_level}</span></td>
                <td>
                    <form action="/admin/update_emergency_status" method="POST" style="margin:0; display:flex; gap: 4px;">
                        <input type="hidden" name="request_id" value="{html.escape(r.request_id)}">
                        <select name="status" style="padding: 4px 8px; font-size: 0.85rem;">
                            {status_options}
                        </select>
                        <button type="submit" class="button button-navy button-sm">Save</button>
                    </form>
                </td>
                <td>
                    <form action="/admin/delete_emergency" method="POST" style="margin:0;">
                        <input type="hidden" name="request_id" value="{html.escape(r.request_id)}">
                        <button type="submit" class="button button-danger button-sm">Delete</button>
                    </form>
                </td>
            </tr>
            """
            rows.append(row)

        table_html = f"""
        <div class="table-responsive">
            <table>
                <thead>
                    <tr><th>Request ID</th><th>Patient</th><th>Blood</th><th>Hospital</th><th>Location</th><th>Units</th><th>Level</th><th>Status Update</th><th>Action</th></tr>
                </thead>
                <tbody>{''.join(rows)}</tbody>
            </table>
        </div>
        """

        content = self._load_template("manage_requests.html")
        content = content.replace("<!--STATUS_MESSAGE-->", status_html)
        content = content.replace("<!--REQUESTS_TABLE-->", table_html)
        self._send_html_response(content)

    def _process_admin_update_emergency_status(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        request_id = form_data.get("request_id", "").strip()
        new_status = form_data.get("status", "Pending").strip()
        updated = AdminService.update_emergency_status(request_id, new_status)
        if updated:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
            status_html = f'<div class="alert success">✅ Emergency Request <strong>{html.escape(request_id)}</strong> status set to <strong>{html.escape(new_status)}</strong>.</div>'
        else:
            status_html = f'<div class="alert error">❌ Could not update request {html.escape(request_id)}.</div>'
        self._render_manage_requests_page({}, status_html)

    def _process_admin_delete_emergency(self, form_data: dict) -> None:
        session, redirect_url = verify_role_access(self.headers, "admin")
        if not session:
            self._send_redirect(redirect_url)
            return
        request_id = form_data.get("request_id", "").strip()
        deleted = AdminService.delete_emergency_request(request_id)
        if deleted:
            AnalyticsEngine.generate_all_charts(FileManager.read_donors(), FileManager.read_emergency_requests())
            status_html = f'<div class="alert success">✅ Request <strong>{html.escape(request_id)}</strong> deleted.</div>'
        else:
            status_html = f'<div class="alert error">❌ Could not delete request {html.escape(request_id)}.</div>'
        self._render_manage_requests_page({}, status_html)

   
    def _render_statistics_page(self) -> None:
        donors = FileManager.read_donors()
        requests = FileManager.read_emergency_requests()

        stats = AnalyticsEngine.compute_summary_statistics(donors, requests)
        donor_df = AnalyticsEngine.build_donor_dataframe(donors)

        # Regenerate charts
        AnalyticsEngine.generate_all_charts(donors, requests)

        stat_cards_html = f"""
        <div class="stats-grid">
            <div class="stat-card">
                <div class="count">{stats['total_donors']}</div>
                <p>Registered Donors</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #10b981;">{stats['available_donors']}</div>
                <p>Active Available</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #2563eb;">{stats['average_age']} <span style="font-size: 1rem;">yrs</span></div>
                <p>Average Age (NumPy Mean)</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #6366f1;">{stats['std_age']}</div>
                <p>Age Std Dev (NumPy)</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #d32f2f;">{stats['availability_rate']}%</div>
                <p>Availability Rate</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #8b5cf6;">{stats['unique_cities_count']}</div>
                <p>Cities Covered</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #f59e0b;">{stats['total_requests']}</div>
                <p>Total Emergency Cases</p>
            </div>
            <div class="stat-card">
                <div class="count" style="color: #ef4444;">{stats['open_requests']}</div>
                <p>Open Urgent Cases</p>
            </div>
        </div>
        """

        # Pandas summary tables
        bg_rows = []
        if not donor_df.empty:
            bg_series = donor_df["Blood Group"].value_counts()
            for bg in ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"):
                cnt = int(bg_series.get(bg, 0))
                pct = round(cnt / len(donors) * 100, 1) if donors else 0.0
                bg_rows.append(f"<tr><td><strong>{bg}</strong></td><td>{cnt}</td><td>{pct}%</td></tr>")
        bg_table = f"""
        <div style="flex: 1; min-width: 300px;">
            <h3 style="color: #0f172a; margin-bottom: 10px;">Blood Group Frequency (Pandas value_counts)</h3>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>Blood Group</th><th>Donors Count</th><th>Percentage</th></tr></thead>
                    <tbody>{''.join(bg_rows)}</tbody>
                </table>
            </div>
        </div>
        """

        city_rows = []
        if not donor_df.empty:
            city_series = donor_df["City"].value_counts().head(8)
            for city_name, cnt in city_series.items():
                pct = round(cnt / len(donors) * 100, 1) if donors else 0.0
                city_rows.append(f"<tr><td><strong>{html.escape(city_name)}</strong></td><td>{cnt}</td><td>{pct}%</td></tr>")
        city_table = f"""
        <div style="flex: 1; min-width: 300px;">
            <h3 style="color: #0f172a; margin-bottom: 10px;">Top Municipal Clusters (Pandas Grouping)</h3>
            <div class="table-responsive">
                <table>
                    <thead><tr><th>City Name</th><th>Donor Count</th><th>Share</th></tr></thead>
                    <tbody>{''.join(city_rows)}</tbody>
                </table>
            </div>
        </div>
        """

        tables_html = f'<div style="display: flex; gap: 24px; flex-wrap: wrap;">{bg_table}{city_table}</div>'

        session = self._get_current_session()
        content = self._load_template("statistics.html")
        content = content.replace("<!--USER_AUTH_NAV-->", self._build_auth_nav_html(session))
        content = content.replace("<!--STAT_CARDS-->", stat_cards_html)
        content = content.replace("<!--DATA_TABLES-->", tables_html)
        self._send_html_response(content)

    
    def _render_about_page(self) -> None:
        session = self._get_current_session()
        content = self._load_template("about.html")
        content = content.replace("<!--USER_AUTH_NAV-->", self._build_auth_nav_html(session))
        self._send_html_response(content)



def start_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    """Initializes data stores, charts, and starts multi-threaded HTTP server."""
    FileManager.ensure_data_directories()
    AnalyticsEngine.ensure_charts_directory()

    donors = FileManager.read_donors()
    requests = FileManager.read_emergency_requests()
    AnalyticsEngine.generate_all_charts(donors, requests)

    server_address = (host, port)
    httpd = ThreadingHTTPServer(server_address, BloodConnectHandler)
    print("=" * 70)
    print("  BloodConnect – Smart Blood Donor Finder Web Server")
    print(f"  URL: http://{host}:{port}")
    print("  Press Ctrl+C to stop server")
    print("=" * 70)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[BloodConnect] Shutting down server gracefully...")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    start_server()
