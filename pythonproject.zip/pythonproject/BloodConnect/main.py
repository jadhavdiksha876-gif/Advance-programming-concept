import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from server import start_server
def main():

    banner = """
    ======================================
    [+] BloodConnect - Smart Blood Donor Finder
    Pure Python Backend | Zero JavaScript | File-Based Storage
    ======================================
    Python Syllabus Topics Active:
    [1] Data Types, [2] Operators, [3] Input & Output
    [4] Control Statements, [5] Branching, [6] Strings & Characters
    [7] Lists, [8] Tuples, [9] Sets, [10] Dictionaries
    [11] Arrays, [12] Functions, [13] Lambda Expressions
    [14] File Handling, [15] Directories, [16] Modules, [17] Packages
    [18] Exception Handling, [19] Procedural, [20] OOP
    [21] Objects & Classes, [22] Method Overloading, [23] Polymorphism
    [24] Inheritance, [25] NumPy, [26] Matplotlib, [27] Pandas
    [28] Regular Expressions (re)
    ======================================
    """

    print(banner)

    start_server(host="127.0.0.1", port=8000)


if __name__ == "__main__":
    main()